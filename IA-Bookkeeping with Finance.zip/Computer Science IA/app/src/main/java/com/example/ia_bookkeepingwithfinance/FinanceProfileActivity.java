package com.example.ia_bookkeepingwithfinance;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class FinanceProfileActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private FirebaseFirestore firestore;

    private TextView termName;
    private TextView termDescription;
    private TextView termLink;
    private String term;
    private String description;
    private String link;

    Term choose;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finance_profile);

        mAuth = FirebaseAuth.getInstance();
        mUser = FirebaseAuth.getInstance().getCurrentUser();
        firestore = FirebaseFirestore.getInstance();

        termName = findViewById(R.id.TermName);
        termDescription = findViewById(R.id.TermDescription);
        termLink = findViewById(R.id.TermLink);

        //get the static object in the FinanceActivity.
        choose = FinanceActivity.term;
    }

    public void setUpButton(View v) {
        //get data from the object get in FinanceActivity.
        term = choose.getTerm();
        description = choose.getDescription();
        link = choose.getLink();

        termName.setText(term);
        termDescription.setText("Definition: \n" + description);
        termLink.setText("Link on Google: \n" + link);
    }

    public void Back(View v) {
        //go to FinanceActivity.
        Intent start = new Intent(this, FinanceActivity.class);
        startActivity(start);
    }
}