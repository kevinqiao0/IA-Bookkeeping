package com.example.ia_bookkeepingwithfinance;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class RecordHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

    protected TextView nameText;
    //set an onClickListener for the recyclerView.
    RecordAdapter.recordListener recordListener;

    public RecordHolder(@NonNull View itemView, RecordAdapter.recordListener recordListener1) {
        super(itemView);
        nameText = itemView.findViewById(R.id.ViewName);
        recordListener = recordListener1;
        itemView.setOnClickListener(this);
    }

    public void onClick(View view) {
        recordListener.recordOnClick(getAdapterPosition());
    }
}
