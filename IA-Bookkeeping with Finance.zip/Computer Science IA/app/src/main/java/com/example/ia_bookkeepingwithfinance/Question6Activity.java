package com.example.ia_bookkeepingwithfinance;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

public class Question6Activity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private FirebaseFirestore firestore;

    private TextView reminder;
    private EditText rentText;
    private EditText commutingText;
    private EditText subscriptionText;
    private EditText otherText;
    private int rentValue;
    private int subscriptionValue;
    private int commutingValue;
    private int otherValue;
    private int totalValue;

    String userEmail;
    String userID;
    String userName;
    String password;
    String userAge;
    String userGender;
    String userCareer;
    String userCurrency;
    String userSalary;
    String userSaving;
    String userFixedCost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question6);

        mAuth = FirebaseAuth.getInstance();
        mUser = FirebaseAuth.getInstance().getCurrentUser();
        firestore = FirebaseFirestore.getInstance();

        reminder = findViewById(R.id.ReminderView);
        rentText = findViewById(R.id.RentText);
        subscriptionText = findViewById(R.id.SubscriptionText);
        commutingText = findViewById(R.id.CommutingText);
        otherText = findViewById(R.id.OtherText);

        DocumentReference documentReference = firestore.collection("User Data").document(mUser.getUid()).collection("SignUp").document("1");
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                //get email, id, password, and name data from Firebase database "User Data" collection.
                userEmail = value.getString("userEmail");
                userID = value.getString("userID");
                password = value.getString("password");
                userName = value.getString("userName");
                System.out.println(userEmail + userID + password + userName);
            }
        });

        DocumentReference documentReference1 = firestore.collection("User Data").document(mUser.getUid()).collection("Question1").document("1");
        documentReference1.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value1, @Nullable FirebaseFirestoreException error) {
                //get age and gender data from Firebase database "User Data" collection.
                userAge = value1.getString("age");
                userGender = value1.getString("gender");
                System.out.println(userAge + userGender);
            }
        });

        DocumentReference documentReference2 = firestore.collection("User Data").document(mUser.getUid()).collection("Question2").document("1");
        documentReference2.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value2, @Nullable FirebaseFirestoreException error) {
                //get career data from Firebase database "User Data" collection.
                userCareer = value2.getString("career");
                System.out.println(userCareer);
            }
        });

        DocumentReference documentReference4 = firestore.collection("User Data").document(mUser.getUid()).collection("Question4").document("1");
        documentReference4.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value4, @Nullable FirebaseFirestoreException error) {
                //get currency and salary data from Firebase database "User Data" collection.
                userCurrency = value4.getString("currency");
                userSalary = value4.getString("money");
                System.out.println(userCurrency + userSalary);
            }
        });

        DocumentReference documentReference5 = firestore.collection("User Data").document(mUser.getUid()).collection("Question5").document("1");
        documentReference5.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value5, @Nullable FirebaseFirestoreException error) {
                //get saving data from Firebase database "User Data" collection.
                userSaving = value5.getString("saving");
                System.out.println(userSaving);
            }
        });
    }

    public void Check(View v) {
        rentValue = Integer.parseInt(rentText.getText().toString());
        subscriptionValue = Integer.parseInt(subscriptionText.getText().toString());
        commutingValue = Integer.parseInt(commutingText.getText().toString());
        otherValue = Integer.parseInt(otherText.getText().toString());

        //check if the inputs are valid, otherwise the App will count them as zero.
        if (rentText == null) {
            rentValue = 0;
        }
        if (subscriptionText == null) {
            subscriptionValue = 0;
        }

        if (commutingText == null) {
            commutingValue = 0;
        }

        if (otherText == null) {
            otherValue = 0;
        }

        //calculate the total amount the fixed cost.
        totalValue = rentValue + subscriptionValue + commutingValue + otherValue;
        reminder.setText("The total amount of fixed is: " + totalValue + ". If it is correct, please click Confirm button.");
    }


    public void Confirm(View v) {
        String totalString = Integer.toString(totalValue);
        //make a new Question6 object.
        Question6 data6 = new Question6(totalString);
        //add the new object into Firebase database "User Data: collection.
        firestore.collection("User Data").document(mUser.getUid()).collection("Question6").document("1").set(data6);
        //make a new User object.
        User currentUser = new User(userName, userID, userGender, userEmail, password, userCareer, userCurrency, userAge, Integer.parseInt(userSalary), Integer.parseInt(userSaving), totalValue);
        //add the new object into Firebase database "User Profile" collection.
        firestore.collection("User Profile").document(userName).set(currentUser);
        //go to UserProfileActivity/
        Intent newPage = new Intent(this, UserProfileActivity.class);
        startActivity(newPage);
    }

    public void Delete(View v) {
        reminder.setText("");
        rentText.setText("Rent");
        subscriptionText.setText("Subscription");
        commutingText.setText("Commuting");
        otherText.setText("Others");
    }

    public void Back(View v) {
        //go back to Question5Activity.
        Intent backPage = new Intent(this, Question5Activity.class);
        startActivity(backPage);
    }
}