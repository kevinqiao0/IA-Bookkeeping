package com.example.ia_bookkeepingwithfinance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

public class Question5Activity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private FirebaseFirestore firestore;

    private TextView reminder;
    private EditText savingField;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question5);

        mAuth = FirebaseAuth.getInstance();
        mUser = FirebaseAuth.getInstance().getCurrentUser();
        firestore = FirebaseFirestore.getInstance();

        reminder = findViewById(R.id.Reminder);
        savingField = findViewById(R.id.SavingText);
    }

    public void Confirm(View v) {
        //check if the input in the plainText is an number
        try {
            String savingText = savingField.getText().toString();
            Integer.parseInt(savingText);
            System.out.println("True!");
            //make a new Question5 object.
            Question5 data5 = new Question5(savingText);
            //add the new object into Firebase database "User Data" collection.
            firestore.collection("User Data").document(mUser.getUid()).collection("Question5").document("1").set(data5);
            Toast.makeText(this, "Confirm: " + savingText, Toast.LENGTH_LONG).show();
            //go to Question6Activity.
            Intent nextQuestion = new Intent(this, Question6Activity.class);
            startActivity(nextQuestion);

        } catch (NumberFormatException e) {
            System.out.println("False!");
            reminder.setText("Please input Arabic Numerials without other signs");
            savingField.setText("");
        }
    }


    public void Delete(View v) {
        savingField.setText("");
    }

    public void Back(View v) {
        //go back to Question4Activity.
        Intent backPage = new Intent(this, Question4Activity.class);
        startActivity(backPage);
    }
}