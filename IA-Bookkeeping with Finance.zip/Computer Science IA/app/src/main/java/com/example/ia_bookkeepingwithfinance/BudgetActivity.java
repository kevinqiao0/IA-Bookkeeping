package com.example.ia_bookkeepingwithfinance;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

public class BudgetActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private FirebaseFirestore firestore;
    int budgetValue;
    private TextView budget;
    private TextView currency;
    private String currencyGet;
    private String moneyGet;
    private String savingGet;
    private int moneyInt;
    private int savingInt;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_budget);

        mAuth = FirebaseAuth.getInstance();
        mUser = FirebaseAuth.getInstance().getCurrentUser();
        firestore = FirebaseFirestore.getInstance();

        budget = findViewById(R.id.BudgetView);
        currency = findViewById(R.id.CurrencyView);

        DocumentReference documentReference = firestore.collection("User Data").document(mUser.getUid()).collection("Question4").document("1");
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                //get data from firebase "UserData" collection.
                moneyGet = value.getString("money");
                currencyGet = value.getString("currency");
                moneyInt = Integer.parseInt(moneyGet);
            }
        });

        DocumentReference documentReference1 = firestore.collection("User Data").document(mUser.getUid()).collection("Question5").document("1");
        documentReference1.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                //get data from Firebase database "User data" collection.
                savingGet = value.getString("saving");
                savingInt = Integer.parseInt(savingGet);
            }
        });
    }

    public void Check(View v) {
        //calculate the total value of the budget.
        budgetValue = moneyInt - savingInt;
        String totalBudgetS = Integer.toString(budgetValue);
        //set the textView.
        budget.setText(totalBudgetS);
        currency.setText(currencyGet);
    }

    public void Confirm(View v) {
        //go to MainActivity.
        Intent start = new Intent(this, MainActivity.class);
        startActivity(start);
    }

    public void Change(View v) {
        //go to UserProfileActivity.
        Intent start = new Intent(this, UserProfileActivity.class);
        startActivity(start);
    }
}