package com.example.ia_bookkeepingwithfinance;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecordAdapter extends RecyclerView.Adapter<RecordHolder> {
    private ArrayList<String> nData;
    //set a new Context for the recyclerView.
    private Context context1;
    //set an onClickListener for the recyclerView.
    private recordListener recordListener;

    //set a new constructor.
    public RecordAdapter(ArrayList nameData, Context context1, recordListener recordListener1) {
        this.context1 = context1;
        nData = nameData;
        recordListener = recordListener1;
    }

    @NonNull
    @Override
    public RecordHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //link to the layout of the recyclerView's textView.
        View myView = LayoutInflater.from(parent.getContext()).inflate(R.layout.record_recycler_view, parent, false);
        RecordHolder recordHolder = new RecordHolder(myView, recordListener);
        return recordHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecordHolder holder, int position) {
        holder.nameText.setText(nData.get(position));

    }

    @Override
    public int getItemCount() {
        return nData.size();
    }

    public interface recordListener {
        //set the int of the listner.
        void recordOnClick(int p);
    }
}
