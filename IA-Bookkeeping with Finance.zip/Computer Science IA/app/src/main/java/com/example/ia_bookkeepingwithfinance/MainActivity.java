package com.example.ia_bookkeepingwithfinance;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.auth.AdditionalUserInfo;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

public class MainActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private FirebaseFirestore firestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();
        mUser = FirebaseAuth.getInstance().getCurrentUser();
        firestore = FirebaseFirestore.getInstance();

        DocumentReference documentReference = firestore.collection("User Data").document(mUser.getUid()).collection("SignUp").document("1");
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                //get client's name from the "User Data" collection.
                Toast welcomeMessage = Toast.makeText(getApplicationContext(), "Here you are, " + value.getString("userName") + ", welcome! What a nice day today!", Toast.LENGTH_LONG);
                welcomeMessage.show();
            }
        });
    }

    public void goBudget(View v) {
        //go to BudgetActivity.
        Intent backPage = new Intent(this, BudgetActivity.class);
        startActivity(backPage);
    }

    public void goRecords(View v) {
        //go to RecordViewActivity.
        Intent backPage = new Intent(this, RecordViewActivity.class);
        startActivity(backPage);
    }

    public void goCoins(View v) {
        //go to CoinActivity.
        Intent backPage = new Intent(this, CoinActivity.class);
        startActivity(backPage);
    }

    public void goFinance(View v) {
        //go to FinanceActivity.
        Intent backPage = new Intent(this, FinanceActivity.class);
        startActivity(backPage);
    }

    public void goUserProfile(View v) {
        //go to UserProfileActivity.
        Intent backPage = new Intent(this, UserProfileActivity.class);
        startActivity(backPage);
    }
}