package com.example.ia_bookkeepingwithfinance;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class RecordViewActivity extends AppCompatActivity implements RecordAdapter.recordListener {
    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private FirebaseFirestore firestore;
    //set an adapter for the recyclerView.
    private RecordAdapter recordAdapter;
    //set a new ArrayList of the object Records.
    private ArrayList<Records> recordList;

    RecyclerView recordRecyclerView;
    //set a new String ArrayList.
    private ArrayList<String> nameData;
    //set a static object for the further onClickListener.
    public static Records records;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_view);

        mAuth = FirebaseAuth.getInstance();
        mUser = FirebaseAuth.getInstance().getCurrentUser();
        firestore = FirebaseFirestore.getInstance();
        recordRecyclerView = findViewById(R.id.RecordRecyclerView);
        nameData = new ArrayList<>();
        recordList = new ArrayList<>();

        recordAdapter = new RecordAdapter(nameData, this, this::recordOnClick);
        //link to the adapter's constructor.
        recordRecyclerView.setAdapter(recordAdapter);
        recordRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        getAndPopulateData();
    }

    public void getAndPopulateData() {
        String email = mUser.getEmail();
        //get data from Firebase database "Record" collection.
        firestore.collection("Record").whereEqualTo("user", email).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (DocumentSnapshot documentSnapshot : task.getResult().getDocuments()) {
                        Records records = documentSnapshot.toObject(Records.class);
                        recordList.add(records);
                    }

                    for (Records rec : recordList) {
                        //gte the record name data and add into the ArrayList.
                        String nameD = rec.getRecordName();
                        System.out.println(nameD);
                        nameData.add(nameD);
                    }
                    recordAdapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(getApplicationContext(), "You don't have any records.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void goBack(View v) {
        //go back to MainActivity.
        Intent start = new Intent(this, MainActivity.class);
        startActivity(start);
    }

    public void goAdd(View v) {
        //go to AddRecordActivity.
        Intent start = new Intent(this, AddRecordActivity.class);
        startActivity(start);
    }

    public void recordOnClick(int p) {
        //set an int for the listener and go to RecordAdjustmentActivity.
        records = recordList.get(p);
        startActivity(new Intent(this, RecordAdjustmentActivity.class));
    }
}