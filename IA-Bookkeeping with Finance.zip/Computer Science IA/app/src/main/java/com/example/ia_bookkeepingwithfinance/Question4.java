package com.example.ia_bookkeepingwithfinance;

public class Question4 {
    String money;
    String currency;

    public Question4(String money, String currency) {
        this.money = money;
        this.currency = currency;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }
}
