package com.example.ia_bookkeepingwithfinance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

public class CoinActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private FirebaseFirestore firestore;

    private int coin10;
    private int coin5;
    private int coin1;
    private int coin2;
    private int coin05;
    private int coin01;

    private EditText coinTen;
    private EditText coinFive;
    private EditText coinTwo;
    private EditText coinOne;
    private EditText coinOFive;
    private EditText coinOOne;
    private TextView total;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coin);

        coinTen = findViewById(R.id.CoinTen);
        coinFive = findViewById(R.id.CoinFive);
        coinTwo = findViewById(R.id.CoinTwo);
        coinOne = findViewById(R.id.CoinOne);
        coinOFive = findViewById(R.id.CoinZeroFive);
        coinOOne = findViewById(R.id.CoinZeroOne);
        total = findViewById(R.id.ValueText);
    }

    //check if the client enter a valid input, otherwise the App will count the amount as zero.
    public void Calculate(View v) {
        if (coinTen.getText().toString().equals("")) {
            coin10 = 0;
            ;
        } else {
            coin10 = Integer.parseInt(coinTen.getText().toString());
        }

        if (coinFive.getText().toString().equals("")) {
            coin5 = 0;
            ;
        } else {
            coin5 = Integer.parseInt(coinFive.getText().toString());
        }

        if (coinOne.getText().toString().equals("")) {
            coin1 = 0;
            ;
        } else {
            coin1 = Integer.parseInt(coinOne.getText().toString());
        }

        if (coinTwo.getText().toString().equals("")) {
            coin1 = 0;
            ;
        } else {
            coin2 = Integer.parseInt(coinTwo.getText().toString());
        }

        if (coinOFive.getText().toString().equals("")) {
            coin1 = 0;
            ;
        } else {
            coin05 = Integer.parseInt(coinOFive.getText().toString());
        }

        if (coinOOne.getText().toString().equals("")) {
            coin01 = 0;
            ;
        } else {
            coin01 = Integer.parseInt(coinOOne.getText().toString());
        }

        //calculate the total face value of the coins.
        double totalValue = (coin10 * 10) + (coin5 * 5) + (coin2 * 2) + coin1 + (coin05 * 0.5) + (coin01 * 0.1);
        String totalValueString = Double.toString(totalValue);

        if (totalValue == 0) {
            //message to the user if the total value is zero.
            total.setText("You did not enter any coins.");
        } else {
            //show message to the client and recommend methods.
            total.setText("The total face value is: " + totalValueString + ". CLick here to see method for you to spend these coins.");
        }
    }

    public void GoRecommendation(View v) {
        //go to RecommendationActivity.
        Intent goNext = new Intent(this, RecommendationActivity.class);
        startActivity(goNext);
    }


    public void Back(View v) {
        //go to MainActivity.
        Intent back = new Intent(this, MainActivity.class);
        startActivity(back);
    }
}