package com.example.ia_bookkeepingwithfinance;

public class Question1 {
    String Gender;
    String Age;

    public Question1(String gender, String age) {
        Gender = gender;
        Age = age;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        Gender = gender;
    }

    public String getAge() {
        return Age;
    }

    public void setAge(String age) {
        Age = age;
    }
}
