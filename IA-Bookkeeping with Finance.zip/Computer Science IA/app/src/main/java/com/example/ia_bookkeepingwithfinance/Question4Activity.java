package com.example.ia_bookkeepingwithfinance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.protobuf.Value;

import java.util.regex.Pattern;

public class Question4Activity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private FirebaseFirestore firestore;

    private TextView messageText;
    private EditText moneyField;
    private RadioGroup gCurrency;
    private RadioButton bCurrency;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question4);

        mAuth = FirebaseAuth.getInstance();
        mUser = FirebaseAuth.getInstance().getCurrentUser();
        firestore = FirebaseFirestore.getInstance();

        messageText = findViewById(R.id.TextViewMessage);
        moneyField = findViewById(R.id.AmountPaid);
        gCurrency = findViewById(R.id.RadioGroupCurrency);
    }

    public void checkCurrencyButton(View v) {
        //get the inputs from the radioButton in a radioGroup.
        int radioId = gCurrency.getCheckedRadioButtonId();
        bCurrency = findViewById(radioId);
        System.out.println(bCurrency.getText());
        //send the choice of user
        Toast.makeText(this, "Currency selected: " + bCurrency.getText(), Toast.LENGTH_LONG).show();
    }

    public void Confirm(View v) {
        //check if the user does not choose any option.
        if (bCurrency == null || moneyField == null) {
            Toast.makeText(this, "Please select your currency.", Toast.LENGTH_LONG).show();
        } else {
            String moneyWord = moneyField.getText().toString();

            try {
                //check if the input is an integer.
                Integer.parseInt(moneyWord);
                System.out.println("True!");
                Toast.makeText(this, "Confirm: " + moneyWord + ", " + bCurrency, Toast.LENGTH_LONG).show();
                //make a new Question3 object.
                Question4 data4 = new Question4(moneyWord, bCurrency.getText().toString());
                //add the new object into the Firebase database "User Data" collection.
                firestore.collection("User Data").document(mUser.getUid()).collection("Question4").document("1").set(data4);
                //go to Question5Activity.
                Intent nextQuestion = new Intent(this, Question5Activity.class);
                startActivity(nextQuestion);

            } catch (NumberFormatException e) {
                System.out.println("False!");
                messageText.setText("Please input Arabic Numerials.");
                moneyField.setText("");
            }
        }
    }

    public void Delete(View v) {
        moneyField.setText("");
    }

    public void Back(View v) {
        //go back to Question3Activity.
        Intent backPage = new Intent(this, Question3Activity.class);
        startActivity(backPage);
    }
}

