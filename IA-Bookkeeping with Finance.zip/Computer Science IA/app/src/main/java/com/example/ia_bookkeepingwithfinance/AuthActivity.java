package com.example.ia_bookkeepingwithfinance;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

public class AuthActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private FirebaseFirestore firestore;
    private EditText emailField;
    private EditText passwordField;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth);

        mAuth = FirebaseAuth.getInstance();
        mUser = FirebaseAuth.getInstance().getCurrentUser();
        firestore = FirebaseFirestore.getInstance();

        emailField = findViewById(R.id.Email);
        passwordField = findViewById(R.id.Password);
    }

    public void SignIn(View v) {
        System.out.println("Sign in!");
        //get input by client.
        String emailName = emailField.getText().toString();
        String passwordValue = passwordField.getText().toString();

        //go to firebase and check if the Email and Password exist in the Authentication
        mAuth.signInWithEmailAndPassword(emailName, passwordValue).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    //log into Firebase authentication and check client's inout.
                    Log.d("SIGN IN", "Successfully signed in with email and password!");
                    FirebaseUser currentUser = mAuth.getCurrentUser();
                    updateUI(currentUser);
                } else {
                    Log.d("SIGN IN", "Sign in with email and password failed.", task.getException());
                    updateUI(null);
                    //send the message to user
                    Toast messageUser = Toast.makeText(getApplicationContext(), "Your Email or Password is Incorrect, please try again.", Toast.LENGTH_LONG);
                    messageUser.show();
                }
            }
        });
    }

    public void signUp(View v) {
        //go to SignUpActivity.
        Intent starterPage = new Intent(this, SignUpActivity.class);
        startActivity(starterPage);
    }

    public void updateUI(FirebaseUser currentUser) {
        if (currentUser != null) {
            //go to MainActivity
            Intent starterPage = new Intent(this, MainActivity.class);
            startActivity(starterPage);
        }
    }
}