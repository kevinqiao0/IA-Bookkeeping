package com.example.ia_bookkeepingwithfinance;

import java.util.ArrayList;

public class Term {
    ArrayList termList = new ArrayList<>();
    ArrayList methodList = new ArrayList<>();
    String term;
    String description;
    String link;
    String open;

    public Term(String term, String description, String link, String open) {
        this.term = term;
        this.description = description;
        this.link = link;
        this.open = open;
    }

    public Term() {
    }

    public String getTerm() {
        return term;
    }

    public void setTerm(String term) {
        this.term = term;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getOpen() {
        return open;
    }

    public void setOpen(String open) {
        this.open = open;
    }

    @Override
    public String toString() {
        return "Term{" +
                "term='" + term + '\'' +
                ", description='" + description + '\'' +
                ", link='" + link + '\'' +
                '}';
    }
}
