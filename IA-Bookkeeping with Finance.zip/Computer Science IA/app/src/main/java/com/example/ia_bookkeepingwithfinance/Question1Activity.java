package com.example.ia_bookkeepingwithfinance;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class Question1Activity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private FirebaseFirestore firestore;
    //Command+Option+L for formatting
    private RadioGroup gGender;
    private RadioButton bGender;
    private RadioGroup gAge;
    private RadioButton bAge;
    public String gender;
    public String age;
    public ArrayList infoList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question1);

        mAuth = FirebaseAuth.getInstance();
        mUser = FirebaseAuth.getInstance().getCurrentUser();
        firestore = FirebaseFirestore.getInstance();

        gGender = findViewById(R.id.RadioGroupGender);
        gAge = findViewById(R.id.RadioGroupAge);
    }

    public void checkGenderButton(View v) {
        //get the input from the radioButton in the radioGroup.
        int radioId = gGender.getCheckedRadioButtonId();
        bGender = findViewById(radioId);
        System.out.println(bGender.getText());
        //send the choice of client.
        Toast.makeText(this, "Gender selected: " + bGender.getText(), Toast.LENGTH_LONG).show();
    }

    public void checkAgeButton(View v) {
        //get the input from the radioButton in the radioGroup.
        int radioID = gAge.getCheckedRadioButtonId();
        bAge = findViewById(radioID);
        System.out.println(bAge.getText());
        //send the choice of user
        Toast.makeText(this, "Age selected: " + bAge.getText(), Toast.LENGTH_LONG).show();
    }

    public void Confirm(View v) {
        if (bAge == null || bGender == null) {
            //check if the client enters a valid input.
            Toast.makeText(this, "Please select your gender or age.", Toast.LENGTH_LONG).show();
        } else {
            System.out.println("Confirm!" + bGender.getText() + bAge.getText());
            gender = bGender.getText().toString();
            age = bAge.getText().toString();
            //make a new Question1 object.
            Question1 data1 = new Question1(gender, age);
            //add the object data1 into Firebase database, "User Data" collection
            firestore.collection("User Data").document(mUser.getUid()).collection("Question1").document("1").set(data1);

            //send a message to the client.
            Toast.makeText(this, "Confirmed: " + bGender.getText() + ", " + bAge.getText(), Toast.LENGTH_LONG).show();
            //go to Question2 Activity.
            Intent nextQuestion = new Intent(this, Question2Activity.class);
            startActivity(nextQuestion);

            DocumentReference documentReference = firestore.collection("User Profile").document(mUser.getUid()).collection("SignUp").document("1");
            documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
                @Override
                public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                    String email = value.getString("userEmail");
                    System.out.println(email);
                }
            });
        }
    }

    public void Back(View v) {
        //go to AuthActivity.
        Intent backPage = new Intent(this, SignUp.class);
        startActivity(backPage);
    }
}