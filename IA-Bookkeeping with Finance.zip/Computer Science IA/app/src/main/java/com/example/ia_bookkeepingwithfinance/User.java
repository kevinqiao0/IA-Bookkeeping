package com.example.ia_bookkeepingwithfinance;

import java.util.ArrayList;

public class User {
    String userName;
    String userID;
    String userGender;
    String userEmail;
    String userPassword;
    String userCareer;
    String userCurrency;
    String userAge;
    int userSalary;
    int userSaving;
    int userFixedCost;
    ArrayList infoList = new ArrayList<>();

    public User(String userName, String userID, String userGender, String userEmail, String userPassword, String userCareer, String userCurrency, String userAge, int userSalary, int userSaving, int userFixedCost) {
        this.userName = userName;
        this.userID = userID;
        this.userGender = userGender;
        this.userEmail = userEmail;
        this.userPassword = userPassword;
        this.userCareer = userCareer;
        this.userCurrency = userCurrency;
        this.userAge = userAge;
        this.userSalary = userSalary;
        this.userSaving = userSaving;
        this.userFixedCost = userFixedCost;
    }

    public User(String userGender) {
        this.userGender = userGender;
    }

    public String getUserGender() {
        return userGender;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public void setUserGender(String userGender) {
        this.userGender = userGender;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getUserCareer() {
        return userCareer;
    }

    public void setUserCareer(String userCareer) {
        this.userCareer = userCareer;
    }

    public String getUserCurrency() {
        return userCurrency;
    }

    public void setUserCurrency(String userCurrency) {
        this.userCurrency = userCurrency;
    }

    public String getUserAge() {
        return userAge;
    }

    public void setUserAge(String userAge) {
        this.userAge = userAge;
    }

    public int getUserSalary() {
        return userSalary;
    }

    public void setUserSalary(int userSalary) {
        this.userSalary = userSalary;
    }

    public int getUserSaving() {
        return userSaving;
    }

    public void setUserSaving(int userSaving) {
        this.userSaving = userSaving;
    }

    public int getUserFixedCost() {
        return userFixedCost;
    }

    public void setUserFixedCost(int userFixedCost) {
        this.userFixedCost = userFixedCost;
    }

    @Override
    public String toString() {
        return "User{" +
                "userName='" + userName + '\'' +
                ", userGender='" + userGender + '\'' +
                ", userEmail='" + userEmail + '\'' +
                ", userPassword='" + userPassword + '\'' +
                ", userCareer='" + userCareer + '\'' +
                ", userCurrency='" + userCurrency + '\'' +
                ", userAge=" + userAge +
                ", userSalary=" + userSalary +
                ", userSaving=" + userSaving +
                ", userFixedCost=" + userFixedCost +
                '}';
    }
}
