package com.example.ia_bookkeepingwithfinance;

public class Question6 {
    String fixedCost;

    public Question6(String fixedCost) {
        this.fixedCost = fixedCost;
    }

    public String getFixedCost() {
        return fixedCost;
    }

    public void setFixedCost(String fixedCost) {
        this.fixedCost = fixedCost;
    }
}
