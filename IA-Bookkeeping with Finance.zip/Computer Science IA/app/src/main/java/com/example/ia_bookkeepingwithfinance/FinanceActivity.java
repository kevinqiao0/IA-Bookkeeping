package com.example.ia_bookkeepingwithfinance;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class FinanceActivity extends AppCompatActivity implements FinanceAdapter.financeListener {
    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private FirebaseFirestore firestore;

    private FinanceAdapter financeAdapter;
    //set an ArrayList of object "Term"
    private ArrayList<Term> financeList;
    RecyclerView financeRecycler;
    //set a static object for further OnClickListener.
    public static Term term;
    //set an ArrayList for the recyclerView.
    private ArrayList<String> termData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finance);

        financeRecycler = findViewById(R.id.FinanceRecyclerView);
        mAuth = FirebaseAuth.getInstance();
        mUser = FirebaseAuth.getInstance().getCurrentUser();
        firestore = FirebaseFirestore.getInstance();

        termData = new ArrayList<>();
        financeList = new ArrayList<>();

        //set an OnClickListener in the recyclerView.
        financeAdapter = new FinanceAdapter(termData, this, this::financeOnClick);
        //set the adapter of FinanceAdapter.
        financeRecycler.setAdapter(financeAdapter);
        financeRecycler.setLayoutManager(new LinearLayoutManager(this));
        getTerm();
    }

    public void getTerm() {
        //get all documents which have value "1" in the field "open" in "Finance Term" collection from Firebase database.
        firestore.collection("Finance Term").whereEqualTo("open", "1").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (DocumentSnapshot docs : task.getResult().getDocuments()) {
                        //get the object "Term" and add it into the ArrayList.
                        Term term = docs.toObject(Term.class);
                        financeList.add(term);
                    }
                    for (Term term : financeList) {
                        //add the record name in each record into the ArrayList.
                        String termName = term.getTerm();
                        termData.add(termName);
                    }
                    financeAdapter.notifyDataSetChanged();
                } else {
                    //send message to the client.
                    Toast.makeText(getApplicationContext(), "There is no term now.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void financeOnClick(int p) {
        //set an int for the financeOnCLick listener.
        term = financeList.get(p);
        startActivity(new Intent(this, FinanceProfileActivity.class));
    }

    public void Back(View v) {
        //go to MainActivity.
        Intent start = new Intent(this, MainActivity.class);
        startActivity(start);
    }
}