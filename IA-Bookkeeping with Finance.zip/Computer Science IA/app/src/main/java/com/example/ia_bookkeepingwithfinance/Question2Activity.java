package com.example.ia_bookkeepingwithfinance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

public class Question2Activity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private FirebaseFirestore firestore;

    private RadioGroup radioGroupCareer;
    private RadioButton radioButtonCareer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question2);

        mAuth = FirebaseAuth.getInstance();
        mUser = FirebaseAuth.getInstance().getCurrentUser();
        firestore = FirebaseFirestore.getInstance();

        radioGroupCareer = findViewById(R.id.RadioGroupCareer);
    }

    public void checkJobButton(android.view.View view) {
        //get the client's input from the radioButton in the radioGroup.
        int radioId = radioGroupCareer.getCheckedRadioButtonId();
        radioButtonCareer = findViewById(radioId);
        System.out.println(radioButtonCareer.getText());
        //send the choice of the client.
        Toast.makeText(this, "Career selected: " + radioButtonCareer.getText(), Toast.LENGTH_LONG).show();
    }

    public void Confirm(View v) {
        if (radioButtonCareer == null) {
            //check if client enters a valid input.
            //send a message to the client if there is nothing.
            Toast.makeText(this, "Please select your career.", Toast.LENGTH_LONG).show();
        } else {
            System.out.println("Confirm!" + radioButtonCareer.getText());
            //send a success message to the client.
            Toast.makeText(this, "Confirmed: " + radioButtonCareer.getText(), Toast.LENGTH_LONG).show();
            //make a new Question2 object.
            Question2 data2 = new Question2(radioButtonCareer.getText().toString());
            //add the new object in to the Firebase database "User Data" collection.
            firestore.collection("User Data").document(mUser.getUid()).collection("Question2").document("1").set(data2);
            //go to Question3Activity.
            Intent nextQuestion = new Intent(this, Question3Activity.class);
            startActivity(nextQuestion);
        }
    }

    public void Back(View v) {
        //go to Question1Activity.
        Intent backPage = new Intent(this, Question1Activity.class);
        startActivity(backPage);
    }
}