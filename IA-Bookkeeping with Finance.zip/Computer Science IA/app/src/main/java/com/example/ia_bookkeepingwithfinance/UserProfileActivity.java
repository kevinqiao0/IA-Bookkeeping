package com.example.ia_bookkeepingwithfinance;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

public class UserProfileActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private FirebaseFirestore firestore;
    private TextView emailGet;
    private TextView nameGet;
    private TextView ageGet;
    private TextView careerGet;
    private TextView currencyGet;
    private TextView genderGet;
    private TextView passwordGet;
    private TextView salaryGet;
    private TextView fixedCostGet;
    private TextView savingGet;

    private String userEmail;
    private String userID;
    private String password;
    private String userName;
    private String userAge;
    private String userGender;
    private String userCareer;
    private String userCurrency;
    private String userSalary;
    private String userSaving;
    private String userFixedCost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        mAuth = FirebaseAuth.getInstance();
        mUser = FirebaseAuth.getInstance().getCurrentUser();
        firestore = FirebaseFirestore.getInstance();

        emailGet = findViewById(R.id.EmailGet);
        nameGet = findViewById(R.id.NameGet);
        passwordGet = findViewById(R.id.PasswordGet);
        ageGet = findViewById(R.id.AgeGet);
        careerGet = findViewById(R.id.CareerGet);
        genderGet = findViewById(R.id.GenderGet);
        salaryGet = findViewById(R.id.SalaryGet);
        currencyGet = findViewById(R.id.CurrencyGet);
        fixedCostGet = findViewById(R.id.FixedCostGet);
        savingGet = findViewById(R.id.SavingGet);

        DocumentReference documentReference = firestore.collection("User Data").document(mUser.getUid()).collection("SignUp").document("1");
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                //get the email, id, password, and name data from Firebase database "User Data" collection.
                userEmail = value.getString("userEmail");
                userID = value.getString("userID");
                password = value.getString("password");
                userName = value.getString("userName");
                System.out.println(userEmail + userID + password + userName);
            }
        });

        DocumentReference documentReference1 = firestore.collection("User Data").document(mUser.getUid()).collection("Question1").document("1");
        documentReference1.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value1, @Nullable FirebaseFirestoreException error) {
                //get age and gender data from Firebase database "User Data" collection.
                userAge = value1.getString("age");
                userGender = value1.getString("gender");
                System.out.println(userAge + userGender);
            }
        });

        DocumentReference documentReference2 = firestore.collection("User Data").document(mUser.getUid()).collection("Question2").document("1");
        documentReference2.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value2, @Nullable FirebaseFirestoreException error) {
                //get career data from Firebase database "User Data" collection.
                userCareer = value2.getString("career");
                System.out.println(userCareer);
            }
        });

        DocumentReference documentReference4 = firestore.collection("User Data").document(mUser.getUid()).collection("Question4").document("1");
        documentReference4.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value4, @Nullable FirebaseFirestoreException error) {
                //get currency and salary data from Firebase database "User Data" collection.
                userCurrency = value4.getString("currency");
                userSalary = value4.getString("money");
                System.out.println(userCurrency + userSalary);
            }
        });

        DocumentReference documentReference5 = firestore.collection("User Data").document(mUser.getUid()).collection("Question5").document("1");
        documentReference5.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value5, @Nullable FirebaseFirestoreException error) {
                //get saving data from Firebase database "User Data" collection.
                userSaving = value5.getString("saving");
                System.out.println(userSaving);
            }
        });

        DocumentReference documentReference6 = firestore.collection("User Data").document(mUser.getUid()).collection("Question6").document("1");
        documentReference6.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value6, @Nullable FirebaseFirestoreException error) {
                //get fixed cost data from Firebase database "User Data" collection.
                userFixedCost = value6.getString("fixedCost");
                System.out.println(userFixedCost);
            }
        });
    }

    public void CheckProfile(View v) {
        emailGet.setText("Email: " + userEmail);
        nameGet.setText("Name: " + userName);
        passwordGet.setText("Password: " + password);
        ageGet.setText("Age: " + userAge);
        careerGet.setText("Career: " + userCareer);
        genderGet.setText("Gender: " + userGender);
        salaryGet.setText("Salary: " + userSalary);
        currencyGet.setText("Currency: " + userCurrency);
        fixedCostGet.setText("Fixed cost: " + userFixedCost);
        savingGet.setText("Saving: " + userSaving);
    }

    public void Confirm(View v) {
        //go to MainActivity.
        Intent goMain = new Intent(this, MainActivity.class);
        startActivity(goMain);
    }

    public void Change(View v) {
        //go to Question1Activity.
        Intent goChange = new Intent(this, Question1Activity.class);
        startActivity(goChange);
    }
}