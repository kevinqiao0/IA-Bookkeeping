package com.example.ia_bookkeepingwithfinance;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class FinanceAdapter extends RecyclerView.Adapter<FinanceHolder> {
    ArrayList<String> tData;
    //set a Context in the recyclerView.
    Context context;
    //set a listener for the recyclerView.
    private financeListener listener;

    //construct a FinanceAdapter object.
    public FinanceAdapter(ArrayList<String> termData, Context context, financeListener listener1) {
        tData = termData;
        this.context = context;
        listener = listener1;
    }

    @NonNull
    @Override
    public FinanceHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //connect to the layout of single textView in the recyclerView.
        View financeView = LayoutInflater.from(parent.getContext()).inflate(R.layout.finance_recycler_view, parent, false);
        //set a new holder for the adapter.
        FinanceHolder financeHolder = new FinanceHolder(financeView, listener);
        return financeHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull FinanceHolder holder, int position) {
        holder.termText.setText(tData.get(position));
    }


    @Override
    public int getItemCount() {
        return tData.size();
    }


    public interface financeListener {
        //set an int value for the listener.
        void financeOnClick(int p);
    }
}
