package com.example.ia_bookkeepingwithfinance;

public class Question2 {
    String career;

    public Question2(String career) {
        this.career = career;
    }

    public String getCareer() {
        return career;
    }

    public void setCareer(String career) {
        this.career = career;
    }
}
