package com.example.ia_bookkeepingwithfinance;

public class Question3 {
    String time;
    String salary;

    public Question3(String time, String salary) {
        this.time = time;
        this.salary = salary;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }
}
