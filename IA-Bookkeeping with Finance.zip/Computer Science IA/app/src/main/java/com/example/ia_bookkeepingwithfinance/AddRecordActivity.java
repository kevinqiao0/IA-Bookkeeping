package com.example.ia_bookkeepingwithfinance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.icu.text.AlphabeticIndex;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Locale;
import java.util.Random;

public class AddRecordActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private FirebaseFirestore firestore;

    private String userEmail;
    private EditText recordName;
    private RadioGroup paymentMG;
    private RadioButton paymentMB;
    private String paymentMethod;
    private EditText year;
    private EditText month;
    private EditText day;
    private EditText amount;
    private boolean accuracy = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_record);

        mAuth = FirebaseAuth.getInstance();
        mUser = FirebaseAuth.getInstance().getCurrentUser();
        firestore = FirebaseFirestore.getInstance();

        paymentMG = findViewById(R.id.Payment);
        recordName = findViewById(R.id.RecordName);
        amount = findViewById(R.id.Amount);
        year = findViewById(R.id.Year);
        month = findViewById(R.id.Month);
        day = findViewById(R.id.Day);
    }

    public void checkPaymentButton(View v) {
        //get input from the radio button inside a radio group.
        int radioId = paymentMG.getCheckedRadioButtonId();
        paymentMB = findViewById(radioId);
        System.out.println(paymentMB.getText());
        //send the choice of user
        Toast.makeText(this, "Payment Method selected: " + paymentMB.getText(), Toast.LENGTH_LONG).show();
        paymentMethod = paymentMB.getText().toString();
    }

    public void Accuracy(View v) {
        accuracy = true;
    }

    public void Confirm(View v) {

        System.out.println("Add Record!");
        //get all texts from the client's input
        String nameValue = recordName.getText().toString();
        double amountValue = Double.parseDouble(amount.getText().toString());
        int yearValue = Integer.parseInt(year.getText().toString());
        int monthValue = Integer.parseInt(month.getText().toString());
        int dayValue = Integer.parseInt(day.getText().toString());

        if (accuracy = false || amount.getText().toString().equals(null)){
            amountValue = 0;
        }

        userEmail = mUser.getEmail();
        System.out.println(userEmail);

        //add a new object in to Firebase database "Record" collection.
        Records newRecord = new Records(userEmail, nameValue, paymentMethod, yearValue, monthValue, dayValue, amountValue, accuracy);
        firestore.collection("Record").document(nameValue).set(newRecord);
        //send a message to the client.
        Toast messageUser = Toast.makeText(getApplicationContext(), "Successfully added a new record!", Toast.LENGTH_LONG);
        messageUser.show();

        //go to the RecordViewActivity.
        Intent startPage = new Intent(this, RecordViewActivity.class);
        startActivity(startPage);
    }
}