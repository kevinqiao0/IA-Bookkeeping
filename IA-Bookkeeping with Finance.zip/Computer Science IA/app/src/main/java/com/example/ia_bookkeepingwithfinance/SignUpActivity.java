package com.example.ia_bookkeepingwithfinance;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.UUID;

public class SignUpActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private FirebaseFirestore firestore;

    private EditText signUpEmail;
    private EditText signUpPassword;
    private EditText signUpName;
    private TextView reminder;
    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        mAuth = FirebaseAuth.getInstance();
        mUser = FirebaseAuth.getInstance().getCurrentUser();
        firestore = FirebaseFirestore.getInstance();

        signUpName = findViewById(R.id.NameText);
        signUpEmail = findViewById(R.id.EmailValue);
        signUpPassword = findViewById(R.id.PasswordValue);
        reminder = findViewById(R.id.TextReminder);
    }

    public void Signup(View v) {
        System.out.println("Sign Up!");
        String emailN = signUpEmail.getText().toString();
        String passwordV = signUpPassword.getText().toString();
        String nameN = signUpName.getText().toString();
        int length = passwordV.length();
        userId = UUID.randomUUID().toString();

        if (length < 6) {
            //check if the password matches with the requirement.
            System.out.println("Error Setting!");
            String info = "The password should have more than 6 numbers or letters, please try again.";
            reminder.setText(info);
        } else {
            mAuth.createUserWithEmailAndPassword(emailN, passwordV).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        Log.d("SIGN UP", "Successfully Signed up with Email and Password!");
                        FirebaseUser currentUser = mAuth.getCurrentUser();
                        updateUI(currentUser);
                        //make a new SignUp object.
                        SignUp signUp = new SignUp(nameN, emailN, passwordV, userId);
                        //add the new object to the Firebase database "User Data" collection.
                        firestore.collection("User Data").document(mUser.getUid()).collection("SignUp").document("1").set(signUp);

                        //send the message to user
                        Toast messageUser = Toast.makeText(getApplicationContext(), "Successfully signed up by email and password! Welcome " + signUpEmail, Toast.LENGTH_LONG);
                        messageUser.show();
                    } else {
                        Log.w("SIGN UP", "createUserWithEmail: failure", task.getException());
                        updateUI(null);
                        //send the message to user
                        Toast messageToUser = Toast.makeText(getApplicationContext(), "Sign up by user failed, maybe you have already signed up with this account.", Toast.LENGTH_LONG);
                        messageToUser.show();
                    }
                }
            });
        }
    }

    public void updateUI(FirebaseUser currentUser) {
        if (currentUser != null) {
            //go to MainActivity
            Intent startPage = new Intent(this, Question1Activity.class);
            startActivity(startPage);
        }
    }

    public void BackToLogIn(View v) {
        Intent backPage = new Intent(this, AuthActivity.class);
        startActivity(backPage);
    }
}
