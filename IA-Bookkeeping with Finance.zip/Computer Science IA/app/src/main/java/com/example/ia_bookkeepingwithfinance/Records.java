package com.example.ia_bookkeepingwithfinance;

import java.util.ArrayList;

public class Records {
    String userEmail;
    String recordName;
    String paymentM;
    int year;
    int month;
    int day;
    double amount;
    boolean accuracy;
    ArrayList recordList = new ArrayList<>();

    public Records(String userEmail, String recordName, String paymentM, int year, int month, int day, double amount, boolean accuracy) {
        this.userEmail = userEmail;
        this.recordName = recordName;
        this.paymentM = paymentM;
        this.year = year;
        this.month = month;
        this.day = day;
        this.amount = amount;
        this.accuracy = accuracy;
    }

    public Records() {
    }

    ;

    public String getUser() {
        return userEmail;
    }

    public void setUser(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getRecordName() {
        return recordName;
    }

    public void setRecordName(String recordName) {
        this.recordName = recordName;
    }

    public String getPaymentM() {
        return paymentM;
    }

    public void setPaymentM(String paymentM) {
        this.paymentM = paymentM;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public boolean isAccuracy() {
        return accuracy;
    }

    public void setAccuracy(boolean accuracy) {
        this.accuracy = accuracy;
    }

    @Override
    public String toString() {
        return "Records{" +
                "recordName='" + recordName + '\'' +
                ", paymentM='" + paymentM + '\'' +
                ", year=" + year +
                ", month=" + month +
                ", day=" + day +
                ", amount=" + amount +
                ", accuracy=" + accuracy +
                '}';
    }
}
