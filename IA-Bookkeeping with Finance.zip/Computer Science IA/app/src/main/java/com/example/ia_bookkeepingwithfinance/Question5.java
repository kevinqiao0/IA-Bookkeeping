package com.example.ia_bookkeepingwithfinance;

public class Question5 {
    String saving;

    public Question5(String saving) {
        this.saving = saving;
    }

    public String getSaving() {
        return saving;
    }

    public void setSaving(String saving) {
        this.saving = saving;
    }
}
