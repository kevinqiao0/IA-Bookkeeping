package com.example.ia_bookkeepingwithfinance;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class FinanceHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
    protected TextView termText;
    FinanceAdapter.financeListener listener;

    public FinanceHolder(@NonNull View itemView, FinanceAdapter.financeListener listener1) {
        super(itemView);
        //set the termText in to the textView of recyclerView.
        termText = itemView.findViewById(R.id.TermView);
        listener = listener1;
        itemView.setOnClickListener((View.OnClickListener) this);
    }

    @Override
    public void onClick(View view) {
        //get the position of the onClickListener.
        listener.financeOnClick(getAdapterPosition());
    }
}
