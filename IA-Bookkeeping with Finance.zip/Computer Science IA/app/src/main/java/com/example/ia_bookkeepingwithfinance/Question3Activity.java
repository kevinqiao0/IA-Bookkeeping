package com.example.ia_bookkeepingwithfinance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

public class Question3Activity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private FirebaseFirestore firestore;

    private RadioGroup radioGroupSalary;
    private RadioButton radioButtonSalary;

    private RadioGroup radioGroupTime;
    private RadioButton radioButtonTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question3);

        mAuth = FirebaseAuth.getInstance();
        mUser = FirebaseAuth.getInstance().getCurrentUser();
        firestore = FirebaseFirestore.getInstance();

        radioGroupSalary = findViewById(R.id.RadioGroupSalary);
        radioGroupTime = findViewById(R.id.RadioGroupIncome);
    }

    public void checkSalaryButton(View v) {
        //get client's input from a radioButton in a radioGroup.
        int radioId = radioGroupSalary.getCheckedRadioButtonId();
        radioButtonSalary = findViewById(radioId);
        System.out.println(radioButtonSalary.getText());
        //send the choice of the client.
        Toast.makeText(this, "Type selected: " + radioButtonSalary.getText(), Toast.LENGTH_LONG).show();
    }

    public void checkIncomeButton(View v) {
        int radioId = radioGroupTime.getCheckedRadioButtonId();
        radioButtonTime = findViewById(radioId);
        System.out.println(radioButtonTime.getText());
        //send the choice of the client.
        Toast.makeText(this, "Time selected: " + radioButtonTime.getText(), Toast.LENGTH_LONG).show();
    }

    public void Confirm(View v) {
        if (radioButtonSalary == null || radioButtonTime == null) {
            //check if the client enters a valid input.
            Toast.makeText(this, "Please select the type of your income or how often do you get paid", Toast.LENGTH_LONG).show();
        } else {
            System.out.println("Confirm! " + radioButtonSalary.getText() + ", " + radioButtonTime.getText());
            Toast.makeText(this, "Confirmed: " + radioButtonSalary.getText() + ", " + radioButtonTime.getText(), Toast.LENGTH_LONG).show();
            //make a new Question3 object.
            Question3 data3 = new Question3(radioButtonTime.getText().toString(), radioButtonSalary.getText().toString());
            //add the new object into Firebase database "USer Data" collection.
            firestore.collection("User Data").document(mUser.getUid()).collection("Question3").document("1").set(data3);
            //go to Question4Activity.
            Intent nextQuestion = new Intent(this, Question4Activity.class);
            startActivity(nextQuestion);
        }
    }

    public void Back(View v) {
        //go back to Question2Activity.
        Intent backPage = new Intent(this, Question2Activity.class);
        startActivity(backPage);
    }
}
