package com.example.ia_bookkeepingwithfinance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.icu.text.AlphabeticIndex;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

public class RecordAdjustmentActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private FirebaseFirestore firestore;

    private TextView name;
    private EditText amount;
    private EditText payment;
    private EditText day;
    private EditText month;
    private EditText year;
    private boolean accuracy = false;

    private String nameView;
    private double amountView;
    private String paymentView;
    private int dayView;
    private int monthView;
    private int yearView;

    Records select;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_adjustment);
        mAuth = FirebaseAuth.getInstance();
        mUser = FirebaseAuth.getInstance().getCurrentUser();
        firestore = FirebaseFirestore.getInstance();

        name = findViewById(R.id.GetName);
        amount = findViewById(R.id.AmountGet);
        payment = findViewById(R.id.PaymentGet);
        day = findViewById(R.id.DayGet);
        month = findViewById(R.id.MonthGet);
        year = findViewById(R.id.YearGet);

        select = RecordViewActivity.records;
        //get the static object in RecordViewActivity.
    }

    public void show(View v) {
        nameView = select.getRecordName();
        System.out.println(nameView);
        amountView = select.getAmount();
        paymentView = select.getPaymentM();
        dayView = select.getDay();
        monthView = select.getMonth();
        yearView = select.getYear();

        name.setText(nameView);
        String amountString = Double.toString(amountView);
        amount.setText(amountString);
        payment.setText(paymentView);
        String dayString = Integer.toString(dayView);
        day.setText(dayString);
        String monthString = Integer.toString(monthView);
        month.setText(monthString);
        String yearString = Integer.toString(yearView);
        year.setText(yearString);
    }

    public void Accuracy(View v) {
        accuracy = true;
    }

    public void Confirm(View v) {
        double amountInput = Double.parseDouble(amount.getText().toString());
        String paymentInput = payment.getText().toString();
        int dayInput = Integer.parseInt(day.getText().toString());
        int monthInput = Integer.parseInt(month.getText().toString());
        int yearInput = Integer.parseInt(year.getText().toString());

        String email = mUser.getEmail();

        //make a new Records object.
        Records records = new Records(email, nameView, paymentInput, yearInput, monthInput, dayInput, amountInput, accuracy);
        //send new data to the Firebase database "Record" collection.
        firestore.collection("Record").document(nameView).set(records);
        //send message to the client.
        Toast messageUser = Toast.makeText(getApplicationContext(), "Successfully adjusted a record!", Toast.LENGTH_LONG);
        messageUser.show();
        //go to RecordViewActivity.
        Intent startPage = new Intent(this, RecordViewActivity.class);
        startActivity(startPage);
    }

    public void Back(View v) {
        //go back to RecordViewActivity.
        Intent startPage = new Intent(this, RecordViewActivity.class);
        startActivity(startPage);
    }
}